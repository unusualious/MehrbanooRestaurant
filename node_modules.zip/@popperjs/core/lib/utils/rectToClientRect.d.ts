import type { Rect, ClientRectObject } from "../types";
export default function rectToClientRect(rect: Rect): ClientRectObject;
