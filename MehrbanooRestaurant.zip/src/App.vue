<script setup>
import HelloWorld from './components/HelloWorld.vue'
import TheWelcome from './components/TheWelcome.vue'
import Home from './views/Home.vue'
</script>

<template>

  <main>
    <!-- <TheWelcome /> -->
    <Home />
  </main>
</template>

<style scoped>

</style>
