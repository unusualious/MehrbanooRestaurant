<script setup>
import Home from './views/Home.vue'
</script>

<template>

  <main>
    <!-- <TheWelcome /> -->
    <Home />
  </main>
  <div>
      <router-view/>
  </div>
</template>

<style scoped>

</style>
