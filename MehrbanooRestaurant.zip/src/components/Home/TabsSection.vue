<template lang="">
    <div class="container-fluid tabs-section main-sections ">
        <div class="row ">
            <div class="parallax-sight one">
                <div class="tabs-menu col-12">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#launchdinner" type="button" role="tab" aria-controls="pills-home" aria-selected="true">انواع غذا</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#drinks" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">نوشیدنی ها</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#starter" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">هم غذاها</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#breakfast" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">صبحانه</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="launchdinner" role="tabpanel" aria-labelledby="pills-home-tab">
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>چلو جوجه کباب ران </h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">طبخ با 330 گرم ران مرغ</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>چلو جوجه کباب سینه </h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">طبخ با 330 گرم سینه مرغ</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>چلو خورشت فسنجان</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">طبخ با ران یا سینه مرغ</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>چلو قیمه سیب زمینی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">طبخ با 100 گرم گوشت گوسفندی</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>چلو قیمه بادمجان</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">طبخ با 100 گرم گوشت گوسفندی</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>چلو قورمه سبزی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">طبخ با 100 گرم گوشت گوسفندی</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>چلو قیمه نثار</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">طبخ با 200 گرم گوشت گوسفندی</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>زرشک پلو با مرغ</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">برنج ایرانی طبخ با ران یا سینه</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>تهچین خورشتی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">قیمه - قورمه - ترکیبی</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>خوراک جوجه کباب</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">طبخ با 330 گرم سینه یا ران مرغ و دورچین</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-2.png" alt="Img">                                                
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>کشک و بادمجان</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">کشک محلی</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-1.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>میرزاقاسمی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">سرو با نیمرو و نان</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-1.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>شامی پوک</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">سه عدد شامی، سرو با خیارشور گوجه و نان</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-1.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>کوفته برنجی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">یک عدد کوفته با نان</p>
                                <!-- section txt end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-1.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>چلو کره زعفرانی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                                <!-- section txt start -->
                                <p class="item-description">برنج ایرانی و زعفرانی</p>
                                <!-- section txt end -->
                            </div>
                        </div>
                        <div class="tab-pane fade" id="starter" role="tabpanel" aria-labelledby="pills-profile-tab">
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-1.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>ماست بورانی اسنفاج</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-1.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>ماست سنتی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-1.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>زیتون</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-1.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>سبزی خوردن</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-1.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>سالاد شیرازی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                        </div>
                        <div class="tab-pane fade" id="breakfast" role="tabpanel" aria-labelledby="pills-profile-tab">
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>املت </h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>نیمرو </h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>سوسیس تخم مرغ </h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>املت سوسیس </h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end --> 
                                    <!-- section title start -->
                                    <h3>کره پنیر با نون تازه </h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>چای تازه دم </h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                        </div>
                        <div class="tab-pane fade" id="drinks" role="tabpanel" aria-labelledby="pills-contact-tab">
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>شربت زعفرانی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>شربت لیمو</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">۱۴,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>دوغ سنتی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>نوشابه</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                            <div class="menu-item">
                                <div class="item-wrapper">
                                    <!-- items img start -->
                                    <div class="menu-img">
                                        <div class="menu-img-inner">
                                            <img src="/src/images/menu/thumb-3.png" alt="Img">
                                        </div>
                                    </div>
                                    <!-- items img end -->
                                    <!-- section title start -->
                                    <h3>آب معدنی</h3>
                                    <span class="item-divider"></span>
                                    <span class="item-price">؟؟؟,۰۰۰ تومان</span>
                                    <!-- section title end -->
                                </div>
                                <!-- divider start -->
                                <div class="divider-m"></div>
                                <!-- divider end -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {

}
</script>
<style scoped lang="scss">
.tabs-section {
    padding: 0;
    margin-top: -50px;

    .tabs-banner {
        text-align: center;
    }

    .tabs-menu {
        padding: 50px;
        margin-right: 15px;

        .nav {
            display: flex;
            justify-content: center !important;
            flex-wrap: nowrap;
            align-items: flex-start;
            padding: 6px 2px;
            border-radius: 5px;

            li {
                text-align: center;

                button {
                    color: #fff;
                    // font-family: mehrit;
                    font-family: 'marr';
                    font-weight: 800;
                    font-size: 22px;

                    &.active {
                        border-bottom: none !important;
    background-color: transparent;
    color: #eee;
    border-radius: 6px 6px 0 0;
    border: 3px solid #556b2f;
    position: relative;
    font-weight: 600;

                        &::after {
                            content: " ";
                            width: 25px;
                            height: 2px;
                            background-color: #556b2f;
                            position: absolute;
                            bottom:0;
                            right: -25px;
                        }
                        &::before {
                            content: " ";
                            width: 25px;
                            height: 2px;
                            background-color: #556b2f;
                            position: absolute;
                            bottom: 0;
                            left: -25px;
                        }
                    }
                }
            }
        }

        .tab-content {
            .tab-pane{
                &.active{

    
                padding-top: 15px;
            display: grid;

            @media (min-width: 768px) {
                grid-column-gap: 40px;
                grid-template-columns: repeat(2, 1fr);
            }

            .menu-item {
                margin: 25px 14px;
                padding: 14px 12px;
                border-radius: 14px;
                border: 2px solid #242424;
                &:hover{
                    border-color: #556b2f;
                    cursor: pointer;
                }
                .item-wrapper {
                    display: flex;
                    align-items: baseline;
                    min-height: 90px;

                    .menu-img {
                        position: relative;
                        padding: 0 0 0 95px;
                        width: 80px;
                        height: 80px;

                        .menu-img-inner {
                            width: 80px;
                            height: 80px;
                            -webkit-border-radius: 50%;
                            -moz-border-radius: 50%;
                            -ms-border-radius: 50%;
                            -o-border-radius: 50%;
                            border-radius: 50%;
                            overflow: hidden;

                            img {
                                width: 100%;
                                height: 100%;
                                left: 50%;
                                top: 50%;
                                -webkit-transform: translate(-50%, -50%);
                                -moz-transform: translate(-50%, -50%);
                                -ms-transform: translate(-50%, -50%);
                                -o-transform: translate(-50%, -50%);
                                transform: translate(-50%, -50%);
                                object-fit: cover;
                                object-position: center;
                            }
                        }
                    }

                    .item-price {
                        font-size: 15px;
                        font-weight: 800;
                        text-align: center;
                        text-transform: uppercase;
                        color: #e0e0e0;
                        line-height: 1.5;
                        letter-spacing: 0.04em;
                    }
                    h3{
                        color: #e0e0e0;
                        font-family: unset;
                    }
                }
                 .item-description{
                        color: #e0e0e0;
                        margin-right: 25px;
                    }
            }

            .item-divider {
                flex: 1;
                border-bottom: 1px dashed #e0e0e0;
                margin: 0 15px;
            }
        }
    }
    }
    }



}
</style>