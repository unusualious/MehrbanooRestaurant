<template lang="">

    <!--=== Start About Section ===-->
    <div class="container">
        <div class="row">
            
        </div>
    </div>


    <div class="container-fluid about-us main-sections about-section light-gray-bg">
        <div class="row  align-items-center">
            <div class="col-md-5">
                <!--=== About Content Box ===-->
                <div class="about-content-box content-box-gap mb-40 wow animate__animated animate__fadeInLeft">
                    <div class="section-title section-title-left mb-30">
                        <span class="sub-title">درباره مهربانو</span>
                        <h2>بهترین طعم ها را با ما 
                            خواهید چشید
                        </h2>
                    </div>
                    <p>ما با کادری مجرب و بی نظیر اینجا هستیم تا یک تجربه لذیذ را برایتان بیافرینیم. پس به ما فرصت دهید در سفره شما نقش آفرینی کنیم </p>
                    <a href="menu-seafood.html" class="main-btn btn-red">learn more<i class="far fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-md-7">
                <!--=== About Content Box ===-->
                <div class="about-image-gallery ml-lg-40">
                    <div class="row">
                        <div class="col-md-6">
                            <img src="/src/images/hero/01foodstocks.png" class="mb-40 wow animate__animated animate__fadeInDown"  alt="">
                        </div>
                        <div class="col-md-6">
                            <img src="/src/images/about/image-2.jpg" class="mb-40 wow animate__animated animate__fadeInDown" alt="About Image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss">
    .about-us{
    padding: 70px 0;
    border-radius: 29px;
    margin-top: -60px;
    z-index: 9;

    }
</style>