<template lang="">
<footer class="footer-default light-gray-bg p-r z-1 ">
    <div class="bg_cover" style="background-image: url(/src/images/bg/dot-bg.png);"></div>
    <!--=== Footer Widget Area ===-->
    <div class="footer-widget-area pb-10 pb-40">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-12">
                    <!--=== Footer Widget ===-->
                    <div class="footer-widget about-company-widget  wow fadeInUp">
                        <div class="footer-content">
                            <a href="index.html" class="footer-logo mb-30"><img src="/src/images/logo/logo.png" alt="Brand Logo"></a>
                        </div>
                    </div>
                </div>
                <div class=" col-md-4 .d-none .d-sm-block ">
                    <!--=== Footer Widget ===-->
                    <div class="footer-widget footer-nav-widget  wow fadeInDown">
                        <h4 class="widget-title">دسترسی سریع</h4>
                        <div class="footer-nav-content">
                            <ul class="footer-nav">
                                <li><a href="#">درباره رستوران</a></li>
                                <li><a href="#">اطلاعات تماس</a></li>
                                <li><a href="#">پیشنهاد های ویژه</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <!--=== Footer Widget ===-->
                    <div class="footer-widget contact-info-widget pl-lg-70 mb-40 wow fadeInDown">
                        <div class="contact-info-box mb-20">
                            <h4 class="widget-title">تماس با ما</h4>
                            <span class="title">شماره تماس : :</span>
                            <a href="tel:02126850157">02126850157</a> 
                            <span>  -  </span>
                            <a href="tel:٠٩١٢٨٨٩٧٠٠٨">09128897008</a>
                            <p><a href="mailto:hello@example.com">info@mehrbanoo.restaurant</a></p>
                        </div>
                        <div class="contact-info-box mb-20">
                            <span class="title">نشانی :نیاوران- سه راه یاسر- خیابان تبریزی-کوچه محمودی یک </span>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--=== Copyright Area ===-->
    <div class="copyright-area border-top-1">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!--=== Copyright Text ===-->
                    <div class="copyright-text">
                        <P>&copy; کلیه حقوق این سایت برای رستوران مهربانو محفوظ است</P>
                    </div>
                </div>

            </div>
        </div>
    </div>
</footer><!--=== End Footer ===-->
</template>
<script>
export default {
    
}
</script>
<style lang="">
    
</style>