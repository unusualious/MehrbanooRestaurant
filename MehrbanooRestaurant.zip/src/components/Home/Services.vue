<template lang="">
<section class="features-section main-sections">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-12">
                        <div class="section-title text-center mb-40">
                            <span class="sub-title">  به مهربانو خوش آمدید </span>
                            <h2>چرا مهربانو ؟</h2>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="single-features-item-two animate-hover-icon wow fadeInUp mb-40" style="visibility: visible; animation-name: fadeInUp;">
                            <div class="inner-content">
                                <div class="icon">
                                    <i class="flaticon-romantic-dinner"></i>
                                </div>
                                <div class="text">
                                    <h3 class="title">کیفیت عالی و پیشرو بودن</h3>
                                    <p>ما همواره تلاش می کنیم در خدمت رسانی به مشتریانمان پیشرو باشیم و کیفیت را سرلوحه کار خود قرار دهیم</p>
                                    <a  class="btn-link">بیشتر بخوانید<i class="far fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="single-features-item-two animate-hover-icon wow fadeInDown mb-40" style="visibility: visible; animation-name: fadeInDown;">
                            <div class="inner-content">
                                <div class="icon">
                                    <i class="flaticon-chef-1"></i>
                                </div>
                                <div class="text">
                                    <h3 class="title">آشپزان کارآزموده</h3>
                                    <p>تیم آشپزی شکل گرفته از تجربه و جوانی به ترکیبی از تکنیکهای سنتی و مدرن</p>
                                    <a  class="btn-link">بیشتر بخوانید<i class="far fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="single-features-item-two animate-hover-icon wow fadeInUp mb-40" style="visibility: visible; animation-name: fadeInUp;">
                            <div class="inner-content">
                                <div class="icon">
                                    <i class="flaticon-delivery-man"></i>
                                </div>
                                <div class="text">
                                    <h3 class="title">ارسال سریع</h3>
                                    <p>یکی از مهمترین امتیاز ها برای ما تازه بودن غذا ها و رساندن سریع غذاها بدون مشکل سرد شدن </p>
                                    <a  class="btn-link">بیشتر بخوانید<i class="far fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

</template>
<script>
export default {
    
}
</script>
<style lang="">
    
</style>