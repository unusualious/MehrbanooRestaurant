<template>
    <header class="header-area transparent-header">
    <div class="top-bar">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-7">
                    <div class="top-left">
                        <span class="text">تخویل سریع و رایگان غذا درب منزل شما!</span>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="top-right d-flex align-items-center justify-content-lg-end">
                        <span class="text"><i class="far fa-envelope"></i>ثبت نام کنید تا از تخفیف های ما بهره بگیرید</span>
                        <ul class="social-link">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--=== Header Navigation ===-->
    <div class="header-navigation navigation-one">
        <div class="nav-overlay"></div>
        <div class="container-fluid">
            <!--=== Primary Menu ===-->
            <div class="primary-menu">
                <!--=== Site Branding ===-->
                <div class="site-branding">
                    <!-- <a href="index.html" class="brand-logo"><img src="/src/images/logo/logo-white.png" alt="Site Logo"></a> -->
                    <a href="index.html" class="brand-logo"><img src="/src/images/logo/logo.png" alt="Site Logo"></a>
                </div>
                <!--=== Nav Inner Menu ===-->
                <div class="nav-inner-menu">
                    <div class="nav-menu">
                        <!--=== Mobile Logo ===-->
                        <div class="mobile-logo mb-30 d-block d-xl-none text-center">
                            <a href="index.html" class="brand-logo"><img src="/src/images/logo/logo.png" alt="Site Logo"></a>
                        </div>
                        <!--=== Main Menu ===-->
                        <nav class="main-menu">
                            <ul>
                                <li class="menu-item has-children"><a href="#">خانه</a>
                                    <ul class="sub-menu">
                                        <li><a href="index.html">رستوران مهربانو</a></li>
                                        <li><a href="index-2.html">غذاهای خانگی</a></li>
                                        <li><a href="index-3.html">دسرها</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item has-children"><a href="#">نوشیدنی ها</a>
                                    <ul class="sub-menu">
                                        <li><a href="menu-fastfood.html">شاهکار سرآشپز</a></li>
                                        <li><a href="menu-seafood.html">غذاهای دریایی</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item"><a href="about.html">درباره ما</a></li>
                                <li class="menu-item has-children"><a href="#">خرید</a>
                                    <ul class="sub-menu">
                                        <li><a href="products.html">گالری تصاویر</a></li>
                                        <li><a href="product-details.html">بی نظیر و عالی</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item has-children"><a href="#">بلاگ </a>
                                    <ul class="sub-menu">
                                        <li><a href="blog-standard.html">بلاگ استاندارد</a></li>
                                        <li><a href="blog-details.html">جزئیات بلاگ</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item has-children"><a href="#">صفحه ها</a>
                                    <ul class="sub-menu">
                                        <li><a href="gallery.html">Our Gallery</a></li>
                                        <li><a href="chefs.html">آشپزان ما</a></li>
                                        <li><a href="history.html">Our History</a></li>
                                        <li><a href="reservations.html">Reservations</a></li>
                                        <li><a href="404.html">404</a></li>
                                        <li><a href="faq.html">Faq</a></li>
                                        <li><a href="contact.html">Contact</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                        <!--=== Nav Button ===-->
                        <div class="menu-button mt-40 d-xl-none">
                            <a href="contact.html" class="main-btn btn-red">سفارش میز<i class="fas fa-long-arrow-right"></i></a>
                        </div>
                    </div>
                    <!--=== Nav right Item ===-->
                    <div class="nav-right-item d-flex align-items-center"> 
                        <div class="search-button">
                            <div class="search-btn" data-bs-toggle="modal" data-bs-target="#search-modal"><i class="fas fa-search"></i></div>
                        </div>
                        <div class="nav-call-button">
                            <span><img src="" alt="icon"><a href="tel:000(123)45689">000 (123) 456 89</a></span>
                        </div>
                        <div class="menu-button d-xl-block d-none">
                            <a href="contact.html" class="main-btn btn-red">سفارش میز<i class="fas fa-long-arrow-right"></i></a>
                        </div>
                        <div class="navbar-toggler">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><!--====== End Header ======-->
</template>