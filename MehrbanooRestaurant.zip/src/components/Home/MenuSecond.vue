<template lang="">
    <div>
        
<section class="menu-section pb-80">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-10">
                <!--=== Section Title ===-->
                <div class="section-title text-center mb-50 wow animate__animated animate__fadeInDown">
                    <span class="sub-title">Best food menu</span>
                    <h2>Choose Your Best Menus</h2>
                </div>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col-lg-6">
                <!--=== Menu Image Box ===-->
                <div class="menu-image-box mb-50 pl-lg-30 wow animate__animated animate__fadeInLeft">
                    <img src="/src/images/menu/menu-single-1.jpg" alt="Menu Image">
                </div>
            </div>
            <div class="col-lg-6">
                <!--=== Single Content Box ===-->
                <div class="menu-content-box mb-50">
                    <!--=== Single Menu Item ===-->
                    <div class="single-menu-item mb-30 wow animate__animated animate__fadeInUp">
                        <div class="thumb">
                            <img src="/src/images/menu/thumb-1.png" alt="">
                        </div>
                        <div class="text">
                            <h3 class="item-title-price"><a href="menu-fastfood.html" class="item-title">برنج اعلا</a><span class="dot-border"></span><span class="price">$25</span></h3>
                            <p>قیمه با بادمجان , سیب زمینی</p>
                            <ul class="ratings">
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><span><a href="#">(5k Reviews)</a></span></li>
                            </ul>
                        </div>
                    </div>
                    <!--=== Single Menu Item ===-->
                    <div class="single-menu-item mb-30 wow animate__animated animate__fadeInUp">
                        <div class="thumb">
                            <img src="/src/images/menu/thumb-2.png" alt="">
                        </div>
                        <div class="text">
                            <h3 class="item-title-price"><a href="menu-fastfood.html" class="item-title">میرزاقاسمی</a><span class="dot-border"></span><span class="price">$63</span></h3>
                            <p>با تازه ترین مواد</p>
                            <ul class="ratings">
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><span><a href="#">(5k Reviews)</a></span></li>
                            </ul>
                        </div>
                    </div>
                    <!--=== Single Menu Item ===-->
                    <div class="single-menu-item mb-30 wow animate__animated animate__fadeInUp">
                        <div class="thumb">
                            <img src="/src/images/menu/thumb-3.png" alt="">
                        </div>
                        <div class="text">
                            <h3 class="item-title-price"><a href="menu-fastfood.html" class="item-title">Baked Chicken Wings</a><span class="dot-border"></span><span class="price">$199</span></h3>
                            <p>Roasted langoustine, consommé</p>
                            <ul class="ratings">
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><span><a href="#">(5k Reviews)</a></span></li>
                            </ul>
                        </div>
                    </div>
                    <!--=== Single Menu Item ===-->
                    <div class="single-menu-item mb-30 wow animate__animated animate__fadeInUp">
                        <div class="thumb">
                            <img src="/src/images/menu/thumb-4.png" alt="">
                        </div>
                        <div class="text">
                            <h3 class="item-title-price"><a href="menu-fastfood.html" class="item-title">Seafood Pizza</a><span class="dot-border"></span><span class="price">$352</span></h3>
                            <p>Roasted langoustine, consommé</p>
                            <ul class="ratings">
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><i class="fas fa-star"></i></li>
                                <li><span><a href="#">(5k Reviews)</a></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="">
    
</style>