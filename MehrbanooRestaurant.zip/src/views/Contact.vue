<template lang="">
    <div>
        <section class="page-banner light-red-bg p-r z-1 bg_cover" style="background-image: url(/src/images/hero/banner-1-ripoo.webp);">
            <div class="container ">
                <div class="row">
                    <div class="col-lg-10">
                        <div class="page-banner-content text-center wow fadeInDown">
                            <h1 class="page-title">تماس با ما</h1>
                            <ul class="breadcrumb-link text-white">
                                <li><a href="">خانه</a></li>
                                <li class="active">تماس با ما</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--====== End Breadcrumb Section ======-->
        <!-- <img src="../images/hero/banner-1-ripoo.webp" alt=""> -->
        <div class="container-fluid about-shape-section main-sections">
            <h1>اطلاعات تماس</h1>
            <p>
                
                آدرس رستوران : 
نیاوران- سه راه یاسر- خیابان تبریزی-کوچه محمودی یک            </p>

        </div>
    </div>

</template>
<script>
    import HomeCarouselSection from '../components/Home/HomeCarouselSection.vue'
export default {
    components: {
        HomeCarouselSection
  },
}
</script>
<style lang="">
    
</style>