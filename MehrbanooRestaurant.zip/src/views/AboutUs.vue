<template lang="">
    <div>
        
<HomeCarouselSection />
        <h1>488</h1>
    </div>
</template>
<script>
    import HomeCarouselSection from '../components/Home/HomeCarouselSection.vue'
export default {
    components: {
        HomeCarouselSection
  },
}
</script>
<style lang="">
    
</style>