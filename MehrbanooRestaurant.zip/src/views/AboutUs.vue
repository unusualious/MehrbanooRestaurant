<template lang="">
    <div>
        <section class="page-banner light-red-bg p-r z-1 bg_cover" style="background-image: url(/src/images/hero/banner-1-ripoo.webp);">
            <div class="container ">
                <div class="row">
                    <div class="col-lg-10">
                        <div class="page-banner-content text-center wow fadeInDown">
                            <h1 class="page-title">درباره ما</h1>
                            <ul class="breadcrumb-link text-white">
                                <li><a href="">خانه</a></li>
                                <li class="active">درباره ما</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--====== End Breadcrumb Section ======-->
        <!-- <img src="../images/hero/banner-1-ripoo.webp" alt=""> -->
        <div class="container-fluid about-shape-section main-sections">
            <h1>درباره مهربانو</h1>
            <p>
                ما در مهربانو با استفاده از تجربیات پیشین و با بهره گیری از هنر ناب ایرانی در عرصه آشپزی تلاش کرده ایم که یک سفره ایرانی با حفظ اصالت غذای ایرانی را محیا کرده و در ارائه یک خدمت مناسب برای عزیزان هموطنمان بکوشیم 
            </p>

        </div>
    </div>

</template>
<script>
    import HomeCarouselSection from '../components/Home/HomeCarouselSection.vue'
export default {
    components: {
        HomeCarouselSection
  },
}
</script>
<style lang="">
    
</style>